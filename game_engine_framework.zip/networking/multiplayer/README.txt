This folder contains multiplayer related files.
