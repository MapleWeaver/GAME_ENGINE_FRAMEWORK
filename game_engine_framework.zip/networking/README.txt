This folder contains networking related files.
