This folder contains replication related files.
