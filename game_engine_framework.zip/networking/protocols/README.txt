This folder contains protocols related files.
