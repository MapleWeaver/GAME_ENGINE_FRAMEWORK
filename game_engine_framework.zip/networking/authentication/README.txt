This folder contains authentication related files.
