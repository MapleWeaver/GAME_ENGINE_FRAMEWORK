This folder contains state_machine related files.
