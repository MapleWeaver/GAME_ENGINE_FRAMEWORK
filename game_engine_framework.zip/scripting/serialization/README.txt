This folder contains serialization related files.
