This folder contains event_system related files.
