This folder contains languages related files.
