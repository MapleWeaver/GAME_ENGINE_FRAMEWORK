This folder contains scripting related files.
