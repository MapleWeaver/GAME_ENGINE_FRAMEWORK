This folder contains ai related files.
