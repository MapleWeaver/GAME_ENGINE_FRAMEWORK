This folder contains decision related files.
