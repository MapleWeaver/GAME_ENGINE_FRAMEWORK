This folder contains perception related files.
