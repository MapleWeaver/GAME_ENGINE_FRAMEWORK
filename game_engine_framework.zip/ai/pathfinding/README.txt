This folder contains pathfinding related files.
