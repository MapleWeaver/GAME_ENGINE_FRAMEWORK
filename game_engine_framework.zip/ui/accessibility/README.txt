This folder contains accessibility related files.
