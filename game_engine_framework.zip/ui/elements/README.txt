This folder contains elements related files.
