This folder contains themes related files.
