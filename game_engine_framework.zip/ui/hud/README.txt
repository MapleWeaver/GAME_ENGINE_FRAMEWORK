This folder contains hud related files.
