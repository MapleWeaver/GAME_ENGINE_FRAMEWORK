This folder contains input related files.
