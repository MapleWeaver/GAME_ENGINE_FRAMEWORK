This folder contains rigid_body related files.
