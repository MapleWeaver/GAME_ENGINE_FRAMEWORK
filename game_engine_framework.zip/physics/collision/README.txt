This folder contains collision related files.
