This folder contains constraints related files.
