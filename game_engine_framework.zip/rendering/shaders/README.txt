This folder contains shaders related files.
