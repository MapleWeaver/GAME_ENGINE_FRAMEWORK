This folder contains rendering related files.
