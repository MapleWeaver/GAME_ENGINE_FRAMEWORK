This folder contains materials related files.
