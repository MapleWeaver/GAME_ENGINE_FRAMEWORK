This folder contains optimization related files.
