This folder contains postprocessing related files.
