This folder contains lighting related files.
