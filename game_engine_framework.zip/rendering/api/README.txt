This folder contains api related files.
