This folder contains assets related files.
