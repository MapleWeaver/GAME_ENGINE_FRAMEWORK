This folder contains textures related files.
