This folder contains fonts related files.
