This folder contains models related files.
