This folder contains sounds related files.
