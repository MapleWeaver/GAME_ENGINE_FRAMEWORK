This folder contains voice related files.
