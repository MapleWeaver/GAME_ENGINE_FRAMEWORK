This folder contains audio related files.
