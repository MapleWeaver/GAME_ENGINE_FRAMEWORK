This folder contains music related files.
