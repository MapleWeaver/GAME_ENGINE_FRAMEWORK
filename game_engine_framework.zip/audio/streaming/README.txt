This folder contains streaming related files.
