This folder contains spatial related files.
