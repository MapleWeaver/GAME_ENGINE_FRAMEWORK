This folder contains effects related files.
