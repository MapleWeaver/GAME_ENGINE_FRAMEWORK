This folder contains object related files.
