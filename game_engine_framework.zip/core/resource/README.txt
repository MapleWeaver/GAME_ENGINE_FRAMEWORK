This folder contains resource related files.
