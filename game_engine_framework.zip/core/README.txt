This folder contains core related files.
