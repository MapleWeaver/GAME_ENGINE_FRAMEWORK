This folder contains event related files.
