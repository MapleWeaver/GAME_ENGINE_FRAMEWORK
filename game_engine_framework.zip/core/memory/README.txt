This folder contains memory related files.
