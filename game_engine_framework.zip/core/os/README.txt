This folder contains os related files.
