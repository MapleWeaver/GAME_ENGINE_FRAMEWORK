This folder contains procedural related files.
