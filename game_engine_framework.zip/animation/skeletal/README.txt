This folder contains skeletal related files.
