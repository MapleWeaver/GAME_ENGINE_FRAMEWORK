This folder contains runtime related files.
