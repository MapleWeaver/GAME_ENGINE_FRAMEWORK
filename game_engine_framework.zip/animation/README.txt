This folder contains animation related files.
