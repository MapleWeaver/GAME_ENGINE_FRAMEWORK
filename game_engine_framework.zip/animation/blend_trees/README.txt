This folder contains blend_trees related files.
