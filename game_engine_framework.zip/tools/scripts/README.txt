This folder contains scripts related files.
