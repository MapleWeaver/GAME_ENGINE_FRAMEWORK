This folder contains consoles related files.
