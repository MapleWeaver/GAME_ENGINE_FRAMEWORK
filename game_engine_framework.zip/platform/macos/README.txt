This folder contains macos related files.
