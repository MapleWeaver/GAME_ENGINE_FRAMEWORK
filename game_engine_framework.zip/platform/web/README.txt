This folder contains web related files.
