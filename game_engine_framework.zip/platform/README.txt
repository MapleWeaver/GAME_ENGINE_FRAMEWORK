This folder contains platform related files.
