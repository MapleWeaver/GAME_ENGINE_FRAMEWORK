This folder contains windows related files.
