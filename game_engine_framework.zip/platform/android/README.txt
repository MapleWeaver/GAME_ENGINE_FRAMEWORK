This folder contains android related files.
