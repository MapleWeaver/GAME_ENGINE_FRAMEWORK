This folder contains hot_reload related files.
