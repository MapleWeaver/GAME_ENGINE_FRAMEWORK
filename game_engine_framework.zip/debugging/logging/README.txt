This folder contains logging related files.
