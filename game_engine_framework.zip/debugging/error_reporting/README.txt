This folder contains error_reporting related files.
