This folder contains visualization related files.
