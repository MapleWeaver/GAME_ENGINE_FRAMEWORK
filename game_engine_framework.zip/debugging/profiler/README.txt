This folder contains profiler related files.
